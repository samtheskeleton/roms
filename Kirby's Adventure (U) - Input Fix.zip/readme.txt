Kirby's Adventure - Input Fix
Controllerhead
Version 1.0
2/24/2023


-----------------
-- Information --
-----------------

"I MADE THAT JUMP?!" you scream helplessly as you careen down the bottomless pit unto your untimely death. "WHY WONT HE SWING THE SWORD?!" as the giant hammer of Bonkers pummels you mercilessly into oblivion as you stand there helplessly, sure that you pressed the right button in time. "The stupid lag ate my input..." you thought, innocently, as many of us did... 

As it turns out, you probably did hit that button, but due to an unfortunate design oversight, the game does not prioritize attack and jump inputs over other in-game actions, and your inputs do not register properly. Good news: This hack fixes all that =) 

Attack and jump inputs, in that order, are now the highest priority actions.

Compatible:
Kirby's Adventure (U) (PRG0) [!].nes
Kirby's Adventure (U) (PRG1) [!].nes

*	The Japanese or European versions WILL NOT WORK. If the game crashes in the first level, you probably have a European PAL ROM. There are alot of unlabeled PAL roms floating around. Find an American ROM and don't you dare post an angry review that my shit is broken lol. I will find you. And i will kill you.

**	This patch should play nicely with other Romhacks: You should patch the input fix first. Kirby's Halloween Adventure and Vegetable Valley Nightmare have been tested and work flawlessly, i assume others in the future will too.

***	It is my hope that these solid feeling controls inspire romhackers to pick up KALE and start making levels! It's a powerful editor for a wonderful game. I encourage you to include this patch directly in your work. Credit would be nice =p


---------------------------
-- Technical Explanation --
---------------------------

The game can only handle one change in Kirby's movement state per frame. Every frame, a list of subroutine checks for Kirby movement state changes is iterated though. Once a change in state is detected, it is acted upon and all subsequent checks in the list are ignored. Movement states are as follows:

Movement State:
Stand
Walk
Run
Crouch
Midair
Flight
Ladder
Wall bonk
Skidding turn around
...etc

There are two types of input detection the game uses: it has a byte for BUTTON_HIT and another for BUTTON_HELD. Some actions, such as flying or crouching, check the BUTTON_HELD byte to see if the player is currently holding up or down on the dpad respectively. Other actions, such as jumping, check for BUTTON_HIT, which only occur on the frame that button was first pressed.

The input problem boils down to the order of the list(s) in which changes in Movement State are checked. Sometimes, a skid turn around from running change or a standing to walking change are checked in the list before the jump button. Can you see the problem now? If Kirby turns around or goes from a walk to a run on the same frame he tries to jump, the code never makes it that far in the state change checklist to check for a jump. Bye bye jump input. Whoops...

This hack reorders those checklists so that attack and jump inputs, in that order, are prioritized over other Movement State changes. Each Movement State has it's own separate checklist, so Stand, Walk, Run, (etc) have their own checklists. In order to properly address all of the jump / attack inputs being ignored, i had to go through every relevant state change checklist and reorder the priority.

It gets better: Different abilities have their own set of Stand, Walk, Run, (etc) checklists. They are as follows:

Ability State:
Normal
Fat
Ability (with Normal graphics)
Sword
Hammer
Parasol
StarRod
Underwater / UFO / Flying StarRod (combined)
Fat Underwater (yes really lol)

So each Ability State has different checklists for each Movement State. Why so much code though? It appears to be this way for bankswitching purposes. I had to edit the Standing, Walking, and Running state change checklists for each Ability State, as well as the different swimming / flying states to prioritize attack and jump inputs. That was alot of code to find and change! yw...

Honestly, the state change checklists for each ability state were in no discernable order, and it was kind of shocking how inconsistent the code is lol.

Anyway, i've included a Mesen label file (.mlb) for use in the Mesen emulator debugger; it has all of the Movement State checlist addresses for each ability and state change check routines; as well as some other random information. It is by no means complete, but should be enough to get anyone started in a Kirby hacking / disassembly project.

I hope this makes explanation makes sense, thank you for reading my blog.

Now go enjoy some Kirby!!!

...or better yet, boot up KALE and make a damn Romhack >;)
romhacking.net/utilities/1064/

License: 
CC3
Credit: 
Input Fix - Controllerhead